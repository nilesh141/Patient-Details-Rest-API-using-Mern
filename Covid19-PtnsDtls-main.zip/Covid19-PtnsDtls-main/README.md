# Covid19-PtnsDtls
 A Node-Js crud-application showing the patients details of covid19.
This project takes the patients details as input and saves into a database.
Basiscally works on the Post,patch,Update and Delete operations.
